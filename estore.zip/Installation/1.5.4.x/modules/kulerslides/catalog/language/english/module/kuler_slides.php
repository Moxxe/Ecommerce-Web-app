<?php

$_['heading_title'] = 'Kuler Slides';