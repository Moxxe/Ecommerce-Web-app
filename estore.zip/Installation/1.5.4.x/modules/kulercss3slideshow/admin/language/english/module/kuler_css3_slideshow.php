<?php

/*--------------------------------------------------------------------------/
* @Author		KulerThemes.com http://www.kulerthemes.com
* @Copyright	Copyright (C) 2012 - 2013 KulerThemes.com. All rights reserved.
* @License		KulerThemes.com Proprietary License
/---------------------------------------------------------------------------*/

$_['heading_title'] = 'Kuler CSS3 Slideshow';

$_['error_warning']             = 'Warning: Please check the form carefully for errors!';

?>