<?php
$_['heading_title'] = 'Kuler Accordion';