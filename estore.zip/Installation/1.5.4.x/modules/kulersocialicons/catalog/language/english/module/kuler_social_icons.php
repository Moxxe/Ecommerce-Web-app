<?php
$_['heading_title'] = 'Kuler Social Icons';