<?php
class ModelModuleKBMModLatestComment extends Model
{

}