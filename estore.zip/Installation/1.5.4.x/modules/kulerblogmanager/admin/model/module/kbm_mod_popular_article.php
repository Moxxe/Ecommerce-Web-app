<?php
class ModelModuleKBMPopularArticle extends Model
{

}