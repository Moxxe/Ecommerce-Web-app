<?php

/**
 * Class ModelModuleKBMPopularArticle
 */
class ModelModuleKBMPopularArticle extends Model
{
    public function __construct($registry)
    {
        parent::__construct($registry);
    }
}