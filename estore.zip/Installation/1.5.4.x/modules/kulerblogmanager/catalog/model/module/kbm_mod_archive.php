<?php

/**
 * Class ModelModuleKBMModArchive
 */
class ModelModuleKBMModArchive extends Model
{
    public function __construct($registry)
    {
        parent::__construct($registry);
    }
}