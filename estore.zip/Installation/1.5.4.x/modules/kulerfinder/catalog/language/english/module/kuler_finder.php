<?php
$_['heading_title']             = "Kuler Finder";

$_['text_all_manufacturers']    = 'All Manufacturers';

$_['text_no_results_found']     = 'No results found';
$_['text_load_more']            = 'Load more...';