<?php
$_['heading_title'] = 'Kuler Advanced HTML';