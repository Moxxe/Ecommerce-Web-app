<?php
$_['heading_title'] = 'Kuler Tabs';